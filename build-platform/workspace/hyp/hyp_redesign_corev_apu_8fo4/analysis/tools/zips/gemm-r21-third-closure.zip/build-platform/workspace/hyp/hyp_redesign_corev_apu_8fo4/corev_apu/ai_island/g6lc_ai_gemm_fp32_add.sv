// Copyright 2026 Etienne Cimon
// SPDX-License-Identifier: CERN-OHL-S-2.0 OR LicenseRef-GSys-Commercial
//
// Exact specialization of g6lc_ai_fp_pkg::fp32_add for two FP32 operands.
// Each signed significand fits 25 bits; their aligned sum fits 26. The
// 640-bit dot-product representation is unnecessary on this recurrence.
// Preserve the reference's signed alignment/truncation and zero exponent
// convention, including its non-IEEE corner behavior. This is not a new FPU.
//
// r21: sign-magnitude arithmetic. The reference's arithmetic right shift of
// a negative significand floors, which equals -(magnitude >> d) - sticky.
// Three magnitude sums run in parallel with their corrections folded into
// carry-ins, so no operand negation, sum negation or post-sum increment
// remains in series. Rounding for the 25-bit result is computed from the
// operand halves beside the main sum.
module g6lc_ai_gemm_fp32_add (
  input  logic [31:0] a_i,
  input  logic [31:0] b_i,
  output logic [36:0] result_o
);
  logic az, bz, an, bn, ai, bi, sa, sb;
  logic [7:0] ea, eb, ec, delta_ab, delta_ba, delta;
  logic [23:0] mag_a, mag_b, x_mag, y_full, y_shift;
  logic swap, sx, sy, sticky, corr, same_sign, nonneg;
  logic [24:0] below_or;
  logic [24:0] sum_same, diff_xy, diff_yx, magnitude, rounded;
  logic [25:0] diff_xy_wide;
  logic [24:0] diff_yx_xor, diff_yx_carry;
  logic sign;
  logic [1:0] low_sum, round_inc;
  logic [24:0] leading;
  logic [22:0] subnormal_fraction;
  logic [36:0] candidates [25];
  logic [36:0] finite_result;
  logic nan_result, zero_result;

  assign sa = a_i[31];
  assign sb = b_i[31];
  assign az = a_i[30:0] == '0;
  assign bz = b_i[30:0] == '0;
  assign an = (&a_i[30:23]) && (|a_i[22:0]);
  assign bn = (&b_i[30:23]) && (|b_i[22:0]);
  assign ai = (&a_i[30:23]) && !(|a_i[22:0]);
  assign bi = (&b_i[30:23]) && !(|b_i[22:0]);
  // E = integer-significand exponent + 150. The reference initializes
  // zero's exponent to 0, hence E=150 rather than the subnormal E=1.
  assign ea = az ? 8'd150 : (a_i[30:23] == 0 ? 8'd1 : a_i[30:23]);
  assign eb = bz ? 8'd150 : (b_i[30:23] == 0 ? 8'd1 : b_i[30:23]);
  assign mag_a = {(|a_i[30:23]), a_i[22:0]};
  assign mag_b = {(|b_i[30:23]), b_i[22:0]};
  // Differences run beside the exponent compare, not after its max mux.
  assign delta_ab = ea - eb;
  assign delta_ba = eb - ea;
  assign swap = ea < eb;
  assign ec = swap ? eb : ea;
  assign delta = swap ? delta_ba : delta_ab;
  // X keeps the larger (or equal) exponent and is never shifted.
  assign x_mag = swap ? mag_b : mag_a;
  assign sx = swap ? sb : sa;
  assign y_full = swap ? mag_a : mag_b;
  assign sy = swap ? sa : sb;
  // Shifts of 24 or more clear every bit; the sticky then covers the whole
  // operand, reproducing the reference's -1 for a shifted-out negative value.
  assign y_shift = delta >= 8'd24 ? 24'd0 : (y_full >> delta);
  // Sticky = any bit below the shift amount: constant-width prefix ORs run
  // beside the shifter and the amount only selects one of them.
  for (genvar k = 0; k <= 24; k++) begin : gen_below_or
    if (k == 0) begin : gen_none
      assign below_or[k] = 1'b0;
    end else begin : gen_prefix
      assign below_or[k] = |y_full[k-1:0];
    end
  end
  assign sticky = delta >= 8'd24 ? below_or[24] : below_or[delta[4:0]];
  assign corr = sy && sticky;
  assign same_sign = sx == sy;
  // Same sign: |X| + |Y| + corr. Opposite sign: X - Y - corr, or its negation
  // when the first borrows; the 1 + corr carry is carried as a two-bit term.
  assign sum_same = {1'b0, x_mag} + {1'b0, y_shift} + 25'(corr);
  assign diff_xy_wide = {2'b00, x_mag} + {1'b0, ~{1'b0, y_shift}} + 26'(!corr);
  assign {nonneg, diff_xy} = diff_xy_wide;
  assign diff_yx_xor = {1'b0, y_shift} ^ ~{1'b0, x_mag} ^ {23'd0, corr, !corr};
  assign diff_yx_carry = ((({1'b0, y_shift} & ~{1'b0, x_mag}) |
                           ({1'b0, y_shift} & {23'd0, corr, !corr}) |
                           (~{1'b0, x_mag} & {23'd0, corr, !corr})) << 1);
  assign diff_yx = diff_yx_xor + diff_yx_carry;
  assign magnitude = same_sign ? sum_same : (nonneg ? diff_xy : diff_yx);
  assign sign = same_sign ? sx : (nonneg ? sx : !sx);
  // Rounding for the overflowing same-sign sum, from the operand halves:
  // sum = 2*(Xh + Yh) + low_sum, rounded = (sum >> 1) + (sum[0] & sum[1]),
  // and sum[1] is the parity of Xh + Yh + low_sum[1].
  assign low_sum = 2'(x_mag[0]) + 2'(y_shift[0]) + 2'(corr);
  assign round_inc = 2'(low_sum[1]) +
                     2'(low_sum[0] && (x_mag[1] ^ y_shift[1] ^ low_sum[1]));
  assign rounded = {2'b00, x_mag[23:1]} + {2'b00, y_shift[23:1]} + 25'(round_inc);
  for (genvar b = 0; b < 25; b++) begin : gen_leading
    logic [7:0] exponent_field;
    logic [22:0] fraction;
    logic [4:0] flags;
    logic overflow_sel, subnormal_sel, normal_sel;
    assign leading[b] = magnitude[b] && !(|(magnitude >> (b + 1)));
    assign exponent_field = ec + 8'(b) - 8'd23;
    if (b == 24) begin : gen_round
      assign fraction = rounded[22:0];
      assign flags = {4'd0, low_sum[0]};
    end else begin : gen_exact
      assign fraction = 23'(magnitude << (23 - b));
      assign flags = '0;
    end
    // The exponent-range selects depend on ec only and settle beside the
    // adders; the candidate is a masked OR, not a select chain.
    assign overflow_sel = {1'b0, ec} > 9'(277 - b);
    assign subnormal_sel = {1'b0, ec} < 9'(24 - b);
    assign normal_sel = !overflow_sel && !subnormal_sel;
    assign candidates[b] =
        ({37{overflow_sel}} & {5'b00100, sign, 8'hff, 23'd0}) |
        ({37{subnormal_sel}} & {5'd0, sign, 8'd0, subnormal_fraction}) |
        ({37{normal_sel}} & {flags, sign, exponent_field, fraction});
  end
  always_comb begin
    finite_result = '0;
    for (int b = 0; b < 25; b++)
      finite_result |= candidates[b] & {37{leading[b]}};
  end
  // At most one significand bit is discarded: msb <= 24. There is no
  // subnormal right shift because ec >= 1 (integer exponent >= -149).
  assign subnormal_fraction = 23'(magnitude << (ec - 8'd1));
  assign nan_result = an || bn || (ai && bi && sa != sb);
  assign zero_result = az && bz;
  always_comb begin
    if (nan_result) result_o = {5'b10000, 32'h7fc00000};
    else if (ai) result_o = {5'b00100, sa, 8'hff, 23'd0};
    else if (bi) result_o = {5'b00100, sb, 8'hff, 23'd0};
    else if (zero_result) result_o = {5'd0, (sa & sb), 31'd0};
    else result_o = finite_result;
  end
endmodule
