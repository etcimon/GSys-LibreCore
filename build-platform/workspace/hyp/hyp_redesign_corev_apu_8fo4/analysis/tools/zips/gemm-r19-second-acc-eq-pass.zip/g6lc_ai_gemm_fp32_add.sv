// Copyright 2026 Etienne Cimon
// SPDX-License-Identifier: CERN-OHL-S-2.0 OR LicenseRef-GSys-Commercial
//
// Exact specialization of g6lc_ai_fp_pkg::fp32_add for two FP32 operands.
// Each signed significand fits 25 bits; their aligned sum fits 26. The
// 640-bit dot-product representation is unnecessary on this recurrence.
// Preserve the reference's signed alignment/truncation and zero exponent
// convention, including its non-IEEE corner behavior. This is not a new FPU.
module g6lc_ai_gemm_fp32_add (
  input  logic [31:0] a_i,
  input  logic [31:0] b_i,
  output logic [36:0] result_o
);
  logic az, bz, an, bn, ai, bi;
  logic [7:0] ea, eb, ec;
  logic signed [25:0] ma, mb, aa, ab, sum;
  logic [24:0] magnitude;
  logic [24:0] leading;
  logic [24:0] rounded;
  logic [22:0] subnormal_fraction;
  logic [36:0] candidates [25];
  logic [36:0] finite_result;

  assign az = a_i[30:0] == '0;
  assign bz = b_i[30:0] == '0;
  assign an = (&a_i[30:23]) && (|a_i[22:0]);
  assign bn = (&b_i[30:23]) && (|b_i[22:0]);
  assign ai = (&a_i[30:23]) && !(|a_i[22:0]);
  assign bi = (&b_i[30:23]) && !(|b_i[22:0]);
  // E = integer-significand exponent + 150. The reference initializes
  // zero's exponent to 0, hence E=150 rather than the subnormal E=1.
  assign ea = az ? 8'd150 : (a_i[30:23] == 0 ? 8'd1 : a_i[30:23]);
  assign eb = bz ? 8'd150 : (b_i[30:23] == 0 ? 8'd1 : b_i[30:23]);
  assign ec = ea > eb ? ea : eb;
  assign ma = a_i[31] ? -$signed({2'b00, (|a_i[30:23]), a_i[22:0]}) :
                        $signed({2'b00, (|a_i[30:23]), a_i[22:0]});
  assign mb = b_i[31] ? -$signed({2'b00, (|b_i[30:23]), b_i[22:0]}) :
                        $signed({2'b00, (|b_i[30:23]), b_i[22:0]});
  assign aa = ma >>> (ec - ea);
  assign ab = mb >>> (ec - eb);
  assign sum = aa + ab;
  assign magnitude = sum[25] ? 25'(-sum) : sum[24:0];
  for (genvar b = 0; b < 25; b++) begin : gen_leading
    logic [7:0] exponent_field;
    logic [22:0] fraction;
    logic [4:0] flags;
    assign leading[b] = magnitude[b] && !(|(magnitude >> (b + 1)));
    assign exponent_field = ec + 8'(b) - 8'd23;
    if (b == 24) begin : gen_round
      assign fraction = rounded[22:0];
      assign flags = {4'd0, magnitude[0]};
    end else begin : gen_exact
      assign fraction = 23'(magnitude << (23 - b));
      assign flags = '0;
    end
    // All candidate exponents and constant shifts run beside the leading-bit
    // decode. No encoded-MSB -> exponent -> variable-shift dependency.
    assign candidates[b] =
        ({1'b0, ec} > 9'(277 - b)) ? {5'b00100, sum[25], 8'hff, 23'd0} :
        ({1'b0, ec} < 9'(24 - b)) ? {5'd0, sum[25], 8'd0, subnormal_fraction} :
        {flags, sum[25], exponent_field, fraction};
  end
  always_comb begin
    finite_result = '0;
    for (int b = 0; b < 25; b++)
      finite_result |= candidates[b] & {37{leading[b]}};
  end
  // At most one significand bit is discarded: msb <= 24. There is no
  // subnormal right shift because ec >= 1 (integer exponent >= -149).
  assign rounded = {1'b0, magnitude[24:1]} + 25'(magnitude[0] && magnitude[1]);
  assign subnormal_fraction = 23'(magnitude << (ec - 8'd1));
  always_comb begin
    result_o = finite_result;
    if (an || bn || (ai && bi && a_i[31] != b_i[31]))
      result_o = {5'b10000, 32'h7fc00000};
    else if (ai) result_o = {5'b00100, a_i[31], 8'hff, 23'd0};
    else if (bi) result_o = {5'b00100, b_i[31], 8'hff, 23'd0};
    else if (az && bz) result_o = {5'd0, (a_i[31] & b_i[31]), 31'd0};
  end
endmodule
