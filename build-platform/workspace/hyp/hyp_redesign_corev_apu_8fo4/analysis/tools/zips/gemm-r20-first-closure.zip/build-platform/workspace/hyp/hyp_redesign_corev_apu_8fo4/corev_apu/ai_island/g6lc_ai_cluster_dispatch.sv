// hyp8 provenance: AS-IS (sv-timing emit at the 8-FO4 budget)
// Copyright 2026 Etienne Cimon
// SPDX-License-Identifier: CERN-OHL-S-2.0 OR LicenseRef-GSys-Commercial
//
// Xg6lcai V3/V4: N GEMM engines behind one job interface and one AXI master.
//
// One island job C[m][n] = A[m][k] . B[n][k]^T is split along N: cluster c takes
// the column slice [c*ns, min((c+1)*ns, n)) with ns = ceil(n / Clusters) rounded
// up to a multiple of SliceAlign columns, reads the same A rows, its own B rows
// (ptr_b + c*ns*ldb_bytes) and writes its own columns of the same C panel
// (ptr_c + c*ns*4, row pitch ldc = n). Every engine keeps the single-engine
// contract (g6lc_ai_gemm_seq with ldc_i); nothing about the descriptor changes.
// Slices that come out empty (n < Clusters*SliceAlign) idle and complete at once.
//
// The N masters join through axi_mux with Clusters-prefixed IDs so responses
// route back by construction (no ID aliasing between engines). done_o is the
// AND of the engines (one pulse when the last finishes), err_o the OR, PMU
// cycles the slowest engine, beats the sum. The residency inputs fan out: each
// engine keys its own slice (a resident panel is resident per cluster).
//
// Scaling honesty: Clusters engines multiply MAC/cycle by Clusters; the shared
// port does not widen. A V3/V4 point is MAC-bound only where the port already
// feeds one engine (prefill); decode stays bytes-bound (scaling-100tops.md s5).
module g6lc_ai_cluster_dispatch
  import g6lc_ai_island_cfg_pkg::*;
#(
    parameter int unsigned Clusters   = 2,
    parameter int unsigned AddrWidth  = 64,
    parameter int unsigned DataWidth  = 64,
    parameter int unsigned IdWidth    = 4,   // island-side ID width (mux output)
    parameter int unsigned MaxDim     = 8,
    parameter int unsigned MaxM       = 0,
    parameter int unsigned MaxN       = 0,   // per-cluster N box
    parameter int unsigned MaxK       = 0,
    parameter int unsigned PeLanes    = 4,
    parameter int unsigned OutCols    = 1,
    parameter bit          DotPipeFloat = 1'b0,
    parameter bit          DotPipeInt   = 1'b0,
    parameter int unsigned MaxAROut   = 2,
    parameter int unsigned NrChannels = 1,
    parameter int unsigned ChanShift  = 6,
    parameter bit          ReuseBEn   = 1'b0,
    parameter int unsigned ReuseBSlots = 2,
    parameter bit          ReuseAEn   = 1'b0,
    parameter int unsigned MaxElementBytes = 4,
    // Column slices start on a multiple of this (keeps every slice's C rows
    // beat-aligned for the wide store when n is).
    parameter int unsigned SliceAlign = 16,
    parameter type         axi_req_t  = logic,   // IdWidth
    parameter type         axi_resp_t = logic,
    parameter type         eng_req_t  = logic,   // IdWidth - clog2(Clusters)
    parameter type         eng_resp_t = logic,
    // r11: channel types explicit (no type() -- Verilator's typedef-of-
    // member-select on a parameter type is an internal error).
    parameter type         eng_aw_chan_t = logic,
    parameter type         eng_w_chan_t  = logic,
    parameter type         eng_b_chan_t  = logic,
    parameter type         eng_ar_chan_t = logic,
    parameter type         eng_r_chan_t  = logic,
    parameter type         mst_aw_chan_t = logic,
    parameter type         mst_w_chan_t  = logic,
    parameter type         mst_b_chan_t  = logic,
    parameter type         mst_ar_chan_t = logic,
    parameter type         mst_r_chan_t  = logic
) (
    input  logic        clk_i,
    input  logic        rst_ni,
    input  logic        testmode_i,
    input  logic        start_i,
    input  logic [31:0] m_i,
    input  logic [31:0] n_i,
    input  logic [31:0] k_i,
    input  logic [15:0] lda_i,
    input  logic [15:0] ldb_i,
    input  logic [2:0]  numfmt_i,
    input  logic        accumulate_i,
    input  logic [3:0]  ar_max_i,
    input  logic [AddrWidth-1:0] ptr_a_i,
    input  logic [AddrWidth-1:0] ptr_b_i,
    input  logic [AddrWidth-1:0] ptr_c_i,
    output logic        ready_o,
    output logic        done_o,
    output logic        err_o,
    output logic [31:0] pmu_r_beats_o,
    output logic [31:0] pmu_w_beats_o,
    output logic [31:0] pmu_cycles_o,
    output logic [3:0][31:0] pmu_phase_o,
    output logic [2:0][31:0] pmu_stall_o,
    input  logic        reuse_b_i,
    input  logic [31:0] reuse_b_epoch_i,
    input  logic        reuse_b_invalidate_i,
    output logic        pmu_reuse_b_hit_o,
    input  logic        reuse_a_i,
    input  logic [31:0] reuse_a_epoch_i,
    input  logic        reuse_a_invalidate_i,
    output logic        pmu_reuse_a_hit_o,
    output axi_req_t    axi_req_o,
    input  axi_resp_t   axi_resp_i
);
  localparam int unsigned ClW = (Clusters > 1) ? $clog2(Clusters) : 1;
  localparam int unsigned EngIdW = IdWidth - ((Clusters > 1) ? $clog2(Clusters) : 0);

  // pragma translate_off
  initial begin
    assert (Clusters >= 1 && (Clusters & (Clusters - 1)) == 0)
      else $error("g6lc_ai_cluster_dispatch: Clusters=%0d must be a power of two", Clusters);
    assert (Clusters == 1 || IdWidth > $clog2(Clusters))
      else $error("g6lc_ai_cluster_dispatch: IdWidth=%0d too narrow for %0d clusters", IdWidth, Clusters);
    assert (SliceAlign > 0 && (SliceAlign & (SliceAlign - 1)) == 0)
      else $error("g6lc_ai_cluster_dispatch: SliceAlign must be a power of two");
  end
  // pragma translate_on

  // ---- owned descriptor preparation -----------------------------------------
  // Each request remains owned through preparation, engine launch and join.
  // No engine sees a partially prepared pointer or a live caller reuse key.
  localparam int unsigned ClusterShift = $clog2(Clusters);
  typedef enum logic [3:0] {
    DP_IDLE, DP_ALIGN, DP_MUL_START, DP_MUL_WAIT,
    DP_OFFSETS, DP_ADDR, DP_LAUNCH, DP_RUN
  } dispatch_phase_t;
  dispatch_phase_t phase_q, phase_d;
  logic        start_q;
  logic [31:0] m_q, n_q, k_q, slice_q;
  logic [31:0] slice_round_q;
  logic [15:0] lda_q, ldb_q;
  logic [2:0]  fmt_q;
  logic        acc_q;
  logic [3:0]  armax_q;
  logic [AddrWidth-1:0] pa_q, pb_q, pc_q;
  logic [31:0] row_bytes_b;
  logic reuse_a_q, reuse_b_q;
  logic [31:0] reuse_a_epoch_q, reuse_b_epoch_q;
  logic accept, span_done;
  logic [Clusters-1:0] span_done_vec, span_seen_q;

  // pragma translate_off
  function automatic logic [31:0] slice_cols(input logic [31:0] n);
    logic [31:0] s;
    s = (n + 32'(Clusters) - 32'd1) / 32'(Clusters);
    s = (s + 32'(SliceAlign) - 32'd1) & ~(32'(SliceAlign) - 32'd1);
    return s;
  endfunction
  // pragma translate_on

  

  // Historical pre-r18 auto-correct notes; the owned preparation stages below
  // replace this former combinational slice_cols call.
  // BEGIN sv-timing auto-correct (balance_mux rewrite)
// ----------------------------------------------------------------
// sv-timing: always_ff factorize  (clock-aware ParallelScratch)
// timing-basis: S(s)=max producer C; C(s)=S(s)+L(s); M=max C;
//   N=ceil(M/B) cycles of posedge clk_i  period_ns=0.200000  B=8.000 FO4
// module=g6lc_ai_cluster_dispatch  region=7020  makespan=150.500 FO4  cycle_count=19  deps=0  procedural_ok=true
// OpenSTA (review-only seeds — not set_max_delay):
//   create_clock -name clk_i -period 0.200000 [get_ports clk_i]
// order expect: acc_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to acc_q
// order expect: armax_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to armax_q
// order expect: fmt_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to fmt_q
// order expect: k_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to k_q
// order expect: lda_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to lda_q
// order expect: ldb_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to ldb_q
// order expect: m_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to m_q
// order expect: n_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to n_q
// order expect: pa_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to pa_q
// order expect: pb_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to pb_q
// order expect: pc_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to pc_q
// order expect: slice_q  ready_cycle=19  ready_fo4=150.500  OpenSTA: report_timing -from clk_i -to slice_q
// order expect: start_q  ready_cycle=1  ready_fo4=3.500  OpenSTA: report_timing -from clk_i -to start_q
// --- factor stage 1/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     start_q <= …; // sv-timing: cycle 1/19 on clk_i
//     /* node25167 c=3.50 slack=147.00 */
//     /* node25168 c=3.50 slack=147.00 */
//     /* node25169 c=3.50 slack=147.00 */
//     /* node25170 c=3.50 slack=147.00 */
//     /* node25171 c=3.50 slack=147.00 */
//     /* node25172 c=3.50 slack=147.00 */
//     /* node25173 c=3.50 slack=147.00 */
//     /* node25174 c=3.50 slack=147.00 */
//     /* node25175 c=3.50 slack=147.00 */
//     /* node25176 c=3.50 slack=147.00 */
//     /* node25177 c=3.50 slack=147.00 */
//     /* node25178 c=3.50 slack=147.00 */
//     /* node25179 c=3.50 slack=147.00 */
//     /* node25180 c=3.50 slack=147.00 */
//   end
// end
// --- factor stage 2/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     acc_q <= …; // sv-timing: cycle 2/19 on clk_i
//     armax_q <= …; // sv-timing: cycle 2/19 on clk_i
//     fmt_q <= …; // sv-timing: cycle 2/19 on clk_i
//     k_q <= …; // sv-timing: cycle 2/19 on clk_i
//     lda_q <= …; // sv-timing: cycle 2/19 on clk_i
//     ldb_q <= …; // sv-timing: cycle 2/19 on clk_i
//     m_q <= …; // sv-timing: cycle 2/19 on clk_i
//     n_q <= …; // sv-timing: cycle 2/19 on clk_i
//     pa_q <= …; // sv-timing: cycle 2/19 on clk_i
//     pb_q <= …; // sv-timing: cycle 2/19 on clk_i
//     pc_q <= …; // sv-timing: cycle 2/19 on clk_i
//     /* node25181 c=8.50 slack=142.00 */
//     /* node25182 c=8.50 slack=142.00 */
//     /* node25183 c=8.50 slack=142.00 */
//     /* node25185 c=8.50 slack=142.00 */
//     /* node25186 c=8.50 slack=142.00 */
//     /* node25187 c=8.50 slack=142.00 */
//     /* node25188 c=8.50 slack=142.00 */
//     /* node25189 c=8.50 slack=142.00 */
//     /* node25190 c=8.50 slack=142.00 */
//     /* node25191 c=8.50 slack=142.00 */
//     /* node25192 c=8.50 slack=142.00 */
//   end
// end
// --- factor stage 3/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 3: no capture on this edge (slack) */
//   end
// end
// --- factor stage 4/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 4: no capture on this edge (slack) */
//   end
// end
// --- factor stage 5/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 5: no capture on this edge (slack) */
//   end
// end
// --- factor stage 6/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 6: no capture on this edge (slack) */
//   end
// end
// --- factor stage 7/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 7: no capture on this edge (slack) */
//   end
// end
// --- factor stage 8/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 8: no capture on this edge (slack) */
//   end
// end
// --- factor stage 9/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 9: no capture on this edge (slack) */
//   end
// end
// --- factor stage 10/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 10: no capture on this edge (slack) */
//   end
// end
// --- factor stage 11/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 11: no capture on this edge (slack) */
//   end
// end
// --- factor stage 12/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 12: no capture on this edge (slack) */
//   end
// end
// --- factor stage 13/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 13: no capture on this edge (slack) */
//   end
// end
// --- factor stage 14/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 14: no capture on this edge (slack) */
//   end
// end
// --- factor stage 15/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 15: no capture on this edge (slack) */
//   end
// end
// --- factor stage 16/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 16: no capture on this edge (slack) */
//   end
// end
// --- factor stage 17/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 17: no capture on this edge (slack) */
//   end
// end
// --- factor stage 18/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     /* cycle 18: no capture on this edge (slack) */
//   end
// end
// --- factor stage 19/19  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     slice_q <= …; // sv-timing: cycle 19/19 on clk_i
//     /* node25184 c=150.50 slack=0.00 */
//   end
// end
// ----------------------------------------------------------------
// ----------------------------------------------------------------
// sv-timing: always_ff factorize  (clock-aware ParallelScratch)
// timing-basis: S(s)=max producer C; C(s)=S(s)+L(s); M=max C;
//   N=ceil(M/B) cycles of posedge clk_i  period_ns=0.200000  B=8.000 FO4
// module=g6lc_ai_cluster_dispatch  region=7025  makespan=8.500 FO4  cycle_count=2  deps=0  procedural_ok=true
// OpenSTA (review-only seeds — not set_max_delay):
//   create_clock -name clk_i -period 0.200000 [get_ports clk_i]
// order expect: any_err_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to any_err_q
// order expect: busy_q  ready_cycle=2  ready_fo4=8.500  OpenSTA: report_timing -from clk_i -to busy_q
// order expect: pend_q  ready_cycle=1  ready_fo4=5.500  OpenSTA: report_timing -from clk_i -to pend_q
// --- factor stage 1/2  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     pend_q <= …; // sv-timing: cycle 1/2 on clk_i
//     /* node25202 c=3.50 slack=5.00 */
//     /* node25203 c=3.50 slack=5.00 */
//     /* node25204 c=3.50 slack=5.00 */
//     /* node25207 c=4.50 slack=4.00 */
//     /* node25208 c=5.50 slack=3.00 */
//     /* node25209 c=5.50 slack=3.00 */
//     /* node25210 c=7.50 slack=1.00 */
//     /* node25211 c=6.00 slack=2.50 */
//   end
// end
// --- factor stage 2/2  capture on posedge clk_i ---
// always_ff @(posedge clk_i or negedge rst_ni) begin
//   if (!rst_ni) begin /* reset */ end else begin
//     any_err_q <= …; // sv-timing: cycle 2/2 on clk_i
//     busy_q <= …; // sv-timing: cycle 2/2 on clk_i
//     /* node25205 c=8.50 slack=0.00 */
//     /* node25206 c=8.50 slack=0.00 */
//   end
// end
// ----------------------------------------------------------------
// sv-timing: origin <src>/corev_apu/ai_island/g6lc_ai_cluster_dispatch.sv:126:45 edit=651
  // relocation t1_balance_bundle; balance_mux credit path 7020 node 25184 exclusive residual 150.5->75.2 (latency-neutral) extras=0
  // END sv-timing auto-correct (balance_mux rewrite)
always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      m_q <= '0; n_q <= '0; k_q <= '0;
      lda_q <= '0; ldb_q <= '0; fmt_q <= '0; acc_q <= 1'b0; armax_q <= '0;
      pa_q <= '0; pb_q <= '0; pc_q <= '0;
      reuse_a_q <= 1'b0; reuse_b_q <= 1'b0;
      reuse_a_epoch_q <= '0; reuse_b_epoch_q <= '0;
    end else if (accept) begin
        m_q <= m_i; n_q <= n_i; k_q <= k_i;
        lda_q <= lda_i; ldb_q <= ldb_i; fmt_q <= numfmt_i; acc_q <= accumulate_i;
        armax_q <= ar_max_i;
        pa_q <= ptr_a_i; pb_q <= ptr_b_i; pc_q <= ptr_c_i;
        reuse_a_q <= reuse_a_i; reuse_b_q <= reuse_b_i;
        reuse_a_epoch_q <= reuse_a_epoch_i; reuse_b_epoch_q <= reuse_b_epoch_i;
    end
  end
  // Preserve the original 32-bit modulo rounding, but express the asserted
  // power-of-two division as wiring and put alignment on the next edge.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) slice_round_q <= '0;
    else if (accept)
      slice_round_q <= (n_i + 32'(Clusters) - 32'd1) >> ClusterShift;
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) slice_q <= '0;
    else if (phase_q == DP_ALIGN)
      slice_q <= (slice_round_q + 32'(SliceAlign) - 32'd1) & ~(32'(SliceAlign) - 32'd1);
  end
  assign row_bytes_b = ai_row_bytes(fmt_q, {16'd0, ldb_q});
  // ldb is 16 bits and format scaling is at most four bytes: 18 bits suffice.
  // Parallel bounded products keep all 50 bits before the AddrWidth cast.
  // This preserves pointer arithmetic even when a B-panel span exceeds 4 GiB.
  assign span_done = &(span_seen_q | span_done_vec);
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) span_seen_q <= '0;
    else if (accept) span_seen_q <= '0;
    else if (phase_q == DP_MUL_WAIT) span_seen_q <= span_seen_q | span_done_vec;
  end
  assign accept = start_i && ready_o;
  assign start_q = phase_q == DP_LAUNCH;

  // ---- engines --------------------------------------------------------------------------
  logic        e_start  [Clusters];
  logic [31:0] e_n      [Clusters];
  logic        e_active [Clusters];   // slice is non-empty
  logic        e_ready  [Clusters];
  logic        e_done   [Clusters];
  logic        e_err    [Clusters];
  logic [31:0] e_pmu_r  [Clusters];
  logic [31:0] e_pmu_w  [Clusters];
  logic [31:0] e_pmu_cy [Clusters];
  logic [3:0][31:0] e_phase [Clusters];
  logic [2:0][31:0] e_stall [Clusters];
  logic        e_hit_b  [Clusters];
  logic        e_hit_a  [Clusters];
  logic [AddrWidth-1:0] e_pb [Clusters];
  logic [AddrWidth-1:0] e_pc [Clusters];
  eng_req_t  [Clusters-1:0] e_req;
  eng_resp_t [Clusters-1:0] e_resp;

  // A job is "in flight" from start until every engine has reported done. Idle
  // slices complete on the start cycle.
  logic        busy_q;
  logic [Clusters-1:0] pend_q;     // engines still owed a done
  logic [Clusters-1:0] done_vec;
  logic [Clusters-1:0] active_vec;
  logic [Clusters-1:0] ready_vec;
  logic                any_err_q;

  for (genvar c = 0; c < int'(Clusters); c++) begin : gen_eng
    logic [31:0] col0_q;
    logic [49:0] b_offset_q, span_product;
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) col0_q <= '0;
      else if (phase_q == DP_OFFSETS) col0_q <= 32'(c) * slice_q;
    end
    g6lc_ai_mul_seq #(.WA(32), .WB(18)) i_b_offset (
      .clk_i, .rst_ni, .start_i(phase_q == DP_MUL_START),
      .a_i(col0_q), .b_i(row_bytes_b[17:0]),
      .done_o(span_done_vec[c]), .product_o(span_product)
    );
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) b_offset_q <= '0;
      else if (phase_q == DP_MUL_WAIT && span_done_vec[c]) b_offset_q <= span_product;
    end
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin e_active[c] <= 1'b0; e_n[c] <= '0; end
      else if (phase_q == DP_ADDR) begin
        e_active[c] <= col0_q < n_q;
        e_n[c] <= col0_q < n_q ?
            ((n_q - col0_q > slice_q) ? slice_q : n_q - col0_q) : 32'd0;
      end
    end
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin e_pb[c] <= '0; e_pc[c] <= '0; end
      else if (phase_q == DP_ADDR) begin
        e_pb[c] <= pb_q + AddrWidth'(b_offset_q);
        e_pc[c] <= pc_q + AddrWidth'(col0_q << 2);
      end
    end
    assign e_start[c] = start_q && e_active[c];
    assign active_vec[c] = e_active[c];
    assign done_vec[c] = e_done[c];
    assign ready_vec[c] = e_ready[c];

    g6lc_ai_gemm_seq #(
        .AddrWidth (AddrWidth),
        .DataWidth (DataWidth),
        .IdWidth   (EngIdW),
        .MaxDim    (MaxDim),
        .MaxM      (MaxM),
        .MaxN      (MaxN),
        .MaxK      (MaxK),
        .PeLanes   (PeLanes),
        .OutCols   (OutCols),
        .DotPipeFloat(DotPipeFloat),
        .DotPipeInt  (DotPipeInt),
        .MaxAROut  (MaxAROut),
        .NrChannels(NrChannels),
        .ChanShift (ChanShift),
        .ReuseBEn  (ReuseBEn),
        .ReuseBSlots(ReuseBSlots),
        .ReuseAEn  (ReuseAEn),
        .MaxElementBytes(MaxElementBytes),
        .axi_req_t (eng_req_t),
        .axi_resp_t(eng_resp_t)
    ) i_eng (
        .clk_i, .rst_ni, .testmode_i,
        .start_i  (e_start[c]),
        .m_i      (m_q),
        .n_i      (e_n[c]),
        .k_i      (k_q),
        .lda_i    (lda_q),
        .ldb_i    (ldb_q),
        .ldc_i    (n_q[15:0]),
        .numfmt_i (fmt_q),
        .accumulate_i(acc_q),
        .ar_max_i (armax_q),
        .ptr_a_i  (pa_q),
        .ptr_b_i  (e_pb[c]),
        .ptr_c_i  (e_pc[c]),
        .ready_o  (e_ready[c]),
        .done_o   (e_done[c]),
        .err_o    (e_err[c]),
        .pmu_r_beats_o(e_pmu_r[c]),
        .pmu_w_beats_o(e_pmu_w[c]),
        .pmu_cycles_o (e_pmu_cy[c]),
        .pmu_phase_o  (e_phase[c]),
        .pmu_stall_o  (e_stall[c]),
        .reuse_b_i(reuse_b_q),
        .reuse_b_epoch_i(reuse_b_epoch_q),
        .reuse_b_invalidate_i(reuse_b_invalidate_i),
        .pmu_reuse_b_hit_o(e_hit_b[c]),
        .reuse_a_i(reuse_a_q),
        .reuse_a_epoch_i(reuse_a_epoch_q),
        .reuse_a_invalidate_i(reuse_a_invalidate_i),
        .pmu_reuse_a_hit_o(e_hit_a[c]),
        .axi_req_o  (e_req[c]),
        .axi_resp_i (e_resp[c])
    );
  end

  // ---- job bookkeeping ---------------------------------------------------------------------
  always_comb begin
    phase_d = phase_q;
    unique case (phase_q)
      DP_IDLE: if (accept) phase_d = DP_ALIGN;
      DP_ALIGN: phase_d = DP_OFFSETS;
      DP_OFFSETS: phase_d = DP_MUL_START;
      DP_MUL_START: phase_d = DP_MUL_WAIT;
      DP_MUL_WAIT: if (span_done) phase_d = DP_ADDR;
      DP_ADDR: phase_d = DP_LAUNCH;
      DP_LAUNCH: phase_d = active_vec == '0 ? DP_IDLE : DP_RUN;
      DP_RUN: if ((pend_q & ~done_vec) == '0) phase_d = DP_IDLE;
      default: phase_d = DP_IDLE;
    endcase
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) phase_q <= DP_IDLE;
    else phase_q <= phase_d;
  end
  assign busy_q = phase_q != DP_IDLE;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pend_q <= '0;
      any_err_q <= 1'b0;
    end else begin
      if (accept) begin
        pend_q <= '0;
        any_err_q <= 1'b0;
      end
      if (start_q) begin
        // engines with an empty slice owe nothing
        pend_q <= active_vec;
      end else if (phase_q == DP_RUN) begin
        pend_q <= pend_q & ~done_vec;
      end
      for (int unsigned c = 0; c < Clusters; c++)
        if (phase_q == DP_RUN && pend_q[c] && e_done[c] && e_err[c]) any_err_q <= 1'b1;
    end
  end
  // r7 R1: job-event outputs are flops at the module boundary -- the
  // caller (island/desc) consumes them into its own cones.
  logic done_q, err_q;
  logic done_n, err_now;
  always_comb begin
    // one-cycle done when the last pending engine finishes
    done_n = (start_q && active_vec == '0) ||
             (phase_q == DP_RUN && pend_q != '0 && (pend_q & ~done_vec) == '0);
    err_now = any_err_q;
    for (int unsigned c = 0; c < Clusters; c++)
      if (phase_q == DP_RUN && pend_q[c] && e_done[c] && e_err[c]) err_now = 1'b1;
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin done_q <= 1'b0; err_q <= 1'b0; end
    else begin
      done_q  <= done_n;
      err_q   <= done_n && err_now;
    end
  end
  assign ready_o = !busy_q && (&ready_vec);
  assign done_o  = done_q;
  assign err_o   = err_q;

  // pragma translate_off
  // Preparation owns admission; no completion can escape before engine launch.
  assert property (@(posedge clk_i) disable iff (!rst_ni)
      start_i |-> ready_o);
  assert property (@(posedge clk_i) disable iff (!rst_ni)
      start_q |-> slice_q == slice_cols(n_q));
  for (genvar c = 0; c < Clusters; c++) begin : gen_launch_check
    assert property (@(posedge clk_i) disable iff (!rst_ni)
        e_start[c] |-> e_ready[c] &&
        e_pb[c] == pb_q + AddrWidth'((32'(c) * slice_q) * row_bytes_b) &&
        e_pc[c] == pc_q + AddrWidth'((32'(c) * slice_q) << 2));
  end
  // pragma translate_on

  // PMU: slowest engine's cycles/phases, summed beats and stalls.
  always_comb begin
    pmu_r_beats_o = '0; pmu_w_beats_o = '0; pmu_cycles_o = '0;
    pmu_phase_o = '0; pmu_stall_o = '0;
    pmu_reuse_b_hit_o = 1'b1; pmu_reuse_a_hit_o = 1'b1;
    for (int unsigned c = 0; c < Clusters; c++) begin
      pmu_r_beats_o += e_pmu_r[c];
      pmu_w_beats_o += e_pmu_w[c];
      if (e_pmu_cy[c] > pmu_cycles_o) begin
        pmu_cycles_o = e_pmu_cy[c];
        pmu_phase_o  = e_phase[c];
      end
      for (int unsigned s = 0; s < 3; s++) pmu_stall_o[s] += e_stall[c][s];
      // a job "hit" residency only if every active slice hit
      if (e_active[c] && !e_hit_b[c]) pmu_reuse_b_hit_o = 1'b0;
      if (e_active[c] && !e_hit_a[c]) pmu_reuse_a_hit_o = 1'b0;
    end
  end

  // ---- AXI: Clusters masters -> one, IDs prefixed by the cluster index --------------------
  if (Clusters == 1) begin : gen_single
    assign axi_req_o = e_req[0];
    assign e_resp[0] = axi_resp_i;
  end else begin : gen_mux
    axi_mux #(
        .SlvAxiIDWidth (EngIdW),
        .slv_aw_chan_t (eng_aw_chan_t),
        .mst_aw_chan_t (mst_aw_chan_t),
        .w_chan_t      (eng_w_chan_t),
        .slv_b_chan_t  (eng_b_chan_t),
        .mst_b_chan_t  (mst_b_chan_t),
        .slv_ar_chan_t (eng_ar_chan_t),
        .mst_ar_chan_t (mst_ar_chan_t),
        .slv_r_chan_t  (eng_r_chan_t),
        .mst_r_chan_t  (mst_r_chan_t),
        .slv_req_t     (eng_req_t),
        .slv_resp_t    (eng_resp_t),
        .mst_req_t     (axi_req_t),
        .mst_resp_t    (axi_resp_t),
        .NoSlvPorts    (Clusters),
        .MaxWTrans     (4),
        .FallThrough   (1'b0),
        .SpillAw       (1'b1), .SpillW (1'b0), .SpillB (1'b0),
        .SpillAr       (1'b1), .SpillR (1'b0)
    ) i_mux (
        .clk_i, .rst_ni,
        .test_i     (testmode_i),
        .slv_reqs_i (e_req),
        .slv_resps_o(e_resp),
        .mst_req_o  (axi_req_o),
        .mst_resp_i (axi_resp_i)
    );
  end
endmodule
