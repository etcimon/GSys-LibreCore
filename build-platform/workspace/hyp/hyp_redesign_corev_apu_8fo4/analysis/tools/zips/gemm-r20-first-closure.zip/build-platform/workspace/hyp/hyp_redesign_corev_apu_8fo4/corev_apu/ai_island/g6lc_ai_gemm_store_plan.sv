// Copyright 2026 Etienne Cimon
// SPDX-License-Identifier: CERN-OHL-S-2.0 OR LicenseRef-GSys-Commercial
//
// One C-store plan owns the cursor until its B response. Capture committed
// credit, limit/stripe in parallel, then publish a stable burst descriptor.
module g6lc_ai_gemm_store_plan #(
  parameter int unsigned AddrWidth = 64,
  parameter int unsigned DataWidth = 64,
  parameter int unsigned NrChannels = 1,
  parameter int unsigned ChanShift = 6,
  parameter int unsigned MaxBurstBeats = 16,
  parameter int unsigned ShiftW = 1
) (
  input logic clk_i, rst_ni,
  input logic job_start_i,
  input logic [AddrWidth-1:0] base_i,
  input logic [31:0] pitch_words_i,
  input logic request_i, retire_i, retire_row_i,
  input logic [15:0] retire_words_i,
  input logic [31:0] n_i, column_i, committed_i,
  input logic row_complete_i, pair_i, wide_i,
  input logic [ShiftW-1:0] word_shift_i,
  output logic valid_o,
  output logic [AddrWidth-1:0] addr_o,
  output logic [31:0] beats_o
);
  typedef enum logic [2:0] {IDLE, CREDIT, LIMITS, PUBLISH, HOLD} phase_t;
  phase_t phase_q;
  logic [AddrWidth-1:0] address_q, row_base_q, stride_q;
  logic [31:0] remaining_q, committed_q, credit_q, beat_limit_q, stripe_limit_q;
  logic [ShiftW-1:0] shift_q;
  logic row_complete_q, pair_q, wide_q;
  logic [31:0] credit_beats, stripe_beats, stripe_bytes;
  assign addr_o = address_q;
  assign valid_o = phase_q == HOLD;
  assign credit_beats = credit_q >> shift_q;
  assign stripe_bytes = (32'd1 << ChanShift) - (32'(address_q) & ((32'd1 << ChanShift) - 1));
  assign stripe_beats = stripe_bytes >> (wide_q ? $clog2(DataWidth/8) : 3);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin address_q <= '0; row_base_q <= '0; stride_q <= '0; end
    else if (job_start_i) begin
      address_q <= base_i; row_base_q <= base_i;
      stride_q <= AddrWidth'(pitch_words_i) << 2;
    end else if (retire_i) begin
      address_q <= retire_row_i ? row_base_q + stride_q :
          address_q + (AddrWidth'(retire_words_i) << 2);
      if (retire_row_i) row_base_q <= row_base_q + stride_q;
    end
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      remaining_q <= '0; committed_q <= '0;
      row_complete_q <= 1'b0; pair_q <= 1'b0; wide_q <= 1'b0; shift_q <= '0;
    end else if (phase_q == IDLE && request_i && !job_start_i) begin
      remaining_q <= n_i - column_i;
      committed_q <= committed_i - column_i;
      row_complete_q <= row_complete_i; pair_q <= pair_i;
      wide_q <= wide_i; shift_q <= word_shift_i;
    end
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) credit_q <= '0;
    else if (phase_q == CREDIT)
      credit_q <= row_complete_q || remaining_q < committed_q ? remaining_q : committed_q;
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin beat_limit_q <= '0; stripe_limit_q <= '0; end
    else if (phase_q == LIMITS) begin
      beat_limit_q <= credit_beats > MaxBurstBeats ? 32'(MaxBurstBeats) : credit_beats;
      stripe_limit_q <= NrChannels <= 1 ? 32'd255 :
          (stripe_beats == 0 ? 32'd1 : (stripe_beats > 255 ? 32'd255 : stripe_beats));
    end
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) beats_o <= '0;
    else if (phase_q == PUBLISH)
      beats_o <= !pair_q || beat_limit_q == 0 ? 32'd1 :
          (beat_limit_q < stripe_limit_q ? beat_limit_q : stripe_limit_q);
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) phase_q <= IDLE;
    else if (job_start_i) phase_q <= IDLE;
    else begin
      unique case (phase_q)
        IDLE: if (request_i) phase_q <= CREDIT;
        CREDIT: phase_q <= LIMITS;
        LIMITS: phase_q <= PUBLISH;
        PUBLISH: phase_q <= HOLD;
        HOLD: if (retire_i) phase_q <= IDLE;
        default: phase_q <= IDLE;
      endcase
    end
  end
  // pragma translate_off
  assert property (@(posedge clk_i) disable iff (!rst_ni) retire_i |-> valid_o);
  assert property (@(posedge clk_i) disable iff (!rst_ni)
      valid_o && !retire_i && !job_start_i |=> $stable({addr_o, beats_o}) || job_start_i);
  // pragma translate_on
endmodule
